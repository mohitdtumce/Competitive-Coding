#include <iostream>
using namespace std;

int main() {
	while (true) {
		new int;
	}
}

