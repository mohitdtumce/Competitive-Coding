template <typename T, typename V>
class pair1 {
	T first;
	V second;
}
