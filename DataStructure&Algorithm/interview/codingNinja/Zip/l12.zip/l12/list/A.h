class A {
	B b;
};

class B {

};
