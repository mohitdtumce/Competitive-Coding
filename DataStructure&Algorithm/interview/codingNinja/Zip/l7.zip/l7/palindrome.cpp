#include <iostream>
using namespace std;

bool ispal(Node const * head) {

}

int main() {

}

