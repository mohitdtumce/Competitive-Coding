#include <iostream>
#include "student.h"
using namespace std;

int main() {
	char arr[] = "abcd";
	student a(arr);
}

